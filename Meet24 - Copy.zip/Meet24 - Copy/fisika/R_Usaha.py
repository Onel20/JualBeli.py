# Ket :
# W = Usaha
# F = Gaya
# s = jarak

def Usaha(f,s):
    return f*s

def Gaya(w,s):
    return w/s

def Jarak(w,f):
    return w/f