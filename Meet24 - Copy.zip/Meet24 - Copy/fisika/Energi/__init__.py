from . R_EnergiPotensial import EnergiPotensial as Ep
from . R_EnergiKinetik import EnergiKinetik as Ek