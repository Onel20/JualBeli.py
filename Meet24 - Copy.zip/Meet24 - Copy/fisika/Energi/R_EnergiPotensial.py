# Ket :
# Ep = energi potensial
# m = massa
# g = gravitasi
# h = tinggi
def EnergiPotensial(m,g,h):
    return m*g*h