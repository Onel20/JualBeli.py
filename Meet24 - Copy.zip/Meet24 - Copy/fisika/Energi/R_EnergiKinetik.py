# Ket :
# m = massa
# v = kecepatan

def EnergiKinetik(m,v):
    return (m * (v**2))/2