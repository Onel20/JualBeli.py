# Ket :
# p / rho = Massa Jenis
# m = massa
# v = volume

def MassaJenis(m,v):
    return m/v

def Massa(p, v):
    return p*v

def Volume(p,m):
    return m/p