import fisika
import time

import fisika.JualBeli

def batas():
    print("-"*15)
    
waktu_awal = time.time()
print(f"Massa Jenis = {fisika.MassaJenis.MassaJenis(10,2)}")
print(f"Massa = {fisika.MassaJenis.Massa(10,2)}")
print(f"Volume = {fisika.MassaJenis.Volume(10,2)}")

waktu_akhir = time.time()
print(f"waktu yang dibutuhkan : {waktu_akhir - waktu_awal}")

batas()
print(f"Usaha = {fisika.U(12,3)}")
print(f"Usaha = {fisika.G(6,2)}")
print(f"Usaha = {fisika.J(10,2)}")

batas()

print(f"hasil energi potensial : {fisika.Ep(4,7,4)}")

batas()

diskon10 = fisika.Diskon(10)
print(f"diskon 10% dari 100 adalah = {diskon10(100)}")